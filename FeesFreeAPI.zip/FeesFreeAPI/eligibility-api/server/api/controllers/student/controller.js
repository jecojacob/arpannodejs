import StudentService from '../../services/student.service';
import errorHandler from '../../errorHandler/error.handler';
import CacheService from '../../../common/cache.service';
import l from '../../../common/logger';

const CACHE_ENABLED = (process.env.ELIGIBILITY_API_ENABLED === 'true');
const EligibiltiyCache = (CACHE_ENABLED) ? new CacheService(process.env.ELIGIBILITY_API_CACHE_TTL) : null;

export class Controller {
  byNSN(req, res) {
    let fromCache = (req.query.fromCache) ? (req.query.fromCache === 'true') : true;
    let handleByNSNResponse = function(result){
        res.json(result);
    }

    res.header('interractionid', req.headers.interractionid);

    if(CACHE_ENABLED){
      EligibiltiyCache.get(`byNSN_${req.params.nsn}`, fromCache,
                          () =>   StudentService.byNSN(req.params.nsn))
                      .then(handleByNSNResponse)
                      .catch((error) => {
                         errorHandler(error, res);
                      });
    }else{
        StudentService.byNSN(req.params.nsn)
          .then(handleByNSNResponse)
          .catch((error) => {
             errorHandler(error, res);
          });
    }
  }
}
export default new Controller();
