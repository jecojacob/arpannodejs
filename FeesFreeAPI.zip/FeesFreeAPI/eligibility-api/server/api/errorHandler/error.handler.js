
const errorHandler = function(error, res){
                      if(error){
                          switch(error.name){
                            case 'ConnectionError':
                                res.status(503).json({message: 'Service Unavailable'}).end();
                                break;
                            case 'RequestError':
                                res.status(400).json(error).end();
                                break;
                            default:
                                res.status(500).json(error).end();
                                break;
                          }
                      }else{
                        res.status(444).json({message: 'No Response'}).end();
                      }
                    };

export default errorHandler;
