import l from '../../common/logger';
import db from './student.db.service';
import _ from 'lodash';
import ReferenceData from '../../common/reference.data.service';

const RefData = new ReferenceData();

class StudentService {

  constructor(){
     let that = this;
     RefData.lookup('eligibility', null).then(
       (refLOV) => {
              that.eligibility = refLOV['eligibility'] || {};
              l.info(`constructor this.eligibility: ${JSON.stringify(that.eligibility,null,2)}`)
       }
     );
  }

  byNSN(NSN) {
    l.info(`${this.constructor.name}.byNSN(${NSN})`);
    let that = this;

    let transformEligibility = function(el){
      l.info(`this.eligibility: ${JSON.stringify(that.eligibility,null,2)}`)
      l.info(`Looping through eligibilityByYear el : ${JSON.stringify(el, null, 2)}`);
      let ItemMap = {};
      if (el.SAC3Eligibility){
          ItemMap.SAC3 = {
              'eligibility': that.eligibility[el.SAC3Eligibility] || el.SAC3Eligibility,
              'reason': ''
          };
      }
      if(el.ITOEligibility){
          ItemMap.ITO = {
              'eligibility':  that.eligibility[el.ITOEligibility] || el.ITOEligibility,
              'reason': ''
          };
      }
      l.info(`Transformed eligibilityByYear : ${JSON.stringify(ItemMap, null, 2)}`);
      return ItemMap;
    };

    return new Promise((resolve, reject)=>{
      db.byNSN(NSN)
          .then((result)=> {
              l.info(`Original by NSN Result: ${JSON.stringify(result, null, 2)}`);
              let transformedResult = _.orderBy(result, ['NSN','StudyYear'], ['asc','desc']);
              transformedResult = _.groupBy(transformedResult, 'NSN');
              transformedResult = _.map(transformedResult, function(item){
                   let itemGroupByYear = _.groupBy(item,'StudyYear');
                   itemGroupByYear =  _.map(itemGroupByYear, function(eligibilityByYear){
                        let mappedResult = _.map(eligibilityByYear, transformEligibility);
                        return {'year': eligibilityByYear[0].StudyYear, ...mappedResult[0]};
                   });
                   return { 'nsn': item[0].NSN, 'eligibility': itemGroupByYear  };
              });
              l.info(`Transformed Results by NSN Result: ${JSON.stringify(transformedResult, null, 2)}`);
              resolve(transformedResult);
           })
          .catch((error) => {
             reject(error);
          });
    });
  }
}

export default new StudentService();
