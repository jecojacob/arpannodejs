
import l from './logger';
import CacheService from './cache.service';
import reflookUp from 'request-promise';

const REF_CACHE_ENABLED = (process.env.REFERENCE_API_CACHE_ENABLED === 'true');

class ReferenceData {

  constructor() {
    this.ReferenceDataCache = (REF_CACHE_ENABLED) ? new CacheService(process.env.REFERENCE_API_CACHE_TTL) : null;
  }

  lookup(domain, key, interractionid) {
    return new Promise((resolve, reject)=>{
        let options = {
          method: 'GET',
          uri: process.env.REFERENCE_API_URL,
          qs: {
              //access_token: 'xxxxx xxxxx' // -> uri + '?access_token=xxxxx%20xxxxx'
          },
          headers: {
              'interractionid': ''
          },
          json: true // Automatically parses the JSON string in the response
        };
        let onlineLookup = function(){
            return new Promise((onlineResolve, onlineReject) => {
              options.uri = `${options.uri}/${domain}`;
              options.headers.interractionid = interractionid;
              if(key){ options.qs.refKey=key; }
              l.info(`request options: ${JSON.stringify(options,null, 2)}`);
              reflookUp(options)
                 .then((body) => { onlineResolve(body); })
                 .catch((err) => { onlineReject(err);   })
            });
        }

        if(REF_CACHE_ENABLED){
          this.ReferenceDataCache.get(`lookup_${domain}${key}`, true, onlineLookup)
                          .then((refData) => { resolve(refData); })
                          .catch((error) =>  { reject(error); });
        }else{
            onlineLookup()
            .then((refData) => { return resolve(refData); })
            .catch((error) =>  { throw reject(error); });
        }
    });
  }
}


export default ReferenceData;
