import studentRouter from './api/controllers/student/router';

export default function routes(app) {
  app.use('/api/v1/students', studentRouter);
}
