import ReferencesService from '../../services/references.service';
import errorHandler from '../../errorHandler/error.handler';
import CacheService from '../../../common/cache.service';
import l from '../../../common/logger';

const CACHE_ENABLED = (process.env.REFERENCE_API_ENABLED === 'true');
const ReferencesCache = (CACHE_ENABLED) ? new CacheService(process.env.REFERENCE_API_CACHE_TTL) : null;

export class Controller {
  refLookUp(req, res) {
    let fromCache = (req.query.fromCache) ? true : (req.query.fromCache === 'true');
    let handleRefLookUpResponse = function(result){
        res.json(result);
    }

    res.header('interractionid', req.headers.interractionid);

    if(CACHE_ENABLED){
      ReferencesCache.get(`refLookUp_${req.params.domain}${req.query.refKey}`, fromCache,
                          () => ReferencesService.refLookUp(req.params.domain, req.query.refKey) )
                      .then(handleRefLookUpResponse)
                      .catch((error) => {
                         errorHandler(error, res);
                      });
    }else{
      ReferencesService.refLookUp(req.params.domain, req.query.refKey)
        .then(handleRefLookUpResponse)
        .catch((error) => {
           errorHandler(error, res);
        });
    }
  }
}
export default new Controller();
