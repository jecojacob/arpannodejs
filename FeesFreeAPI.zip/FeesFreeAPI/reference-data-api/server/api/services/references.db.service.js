import l from '../../common/logger';
import sql from 'mssql';

class ReferencesDatabase {
  constructor() {
    let config = {
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        server: process.env.DB_SERVER, // You can use 'localhost\\instance' to connect to named instance
        database: process.env.DB_NAME, //,
        options: {
             encrypt: (process.env.DB_ENCRYPT === 'true')// Use this if you're on Windows Azure
        },
        pool: {
            max: process.env.DB_POOL_MAX,
            min: process.env.DB_POOL_MIN,
            idleTimeoutMillis: process.env.DB_POOL_TIMEOUT_MILIS
        }
    }

    this.connectionPool = new sql.ConnectionPool(config,  err => {
      if (err){
        console.log(`Error obtaining connection pool to database: ${JSON.stringify(err,null,2)} `);
      }else{
        console.log(`Successfully obtained connection pool to database ...`);
      }
    });
    //this.connectionPool.config.parseJSON = true; //use for sql server 2017 that supports json
  }

refLookUp(domain, refKey) {
    return new Promise((resolve, reject) => {
      this.connectionPool.request().input('Domain', sql.NVarChar, domain).input('Code', sql.NVarChar, refKey).execute('dbo.usp_DomainLookup') //await this.connectionPool.request().query('SELECT * FROM dbo.Candidate');// FOR JSON AUTO'); //use for sql server 2017 that supports json
         .then((result) => {
           l.info(`querry successfull: ${JSON.stringify(result, null, 2)}`);
           resolve(result.recordset);
         })
         .catch((error) => {
           l.error(`querry error: ${error}`);
           reject(error);
         });
    });
  }

}

export default new ReferencesDatabase();
