import l from '../../common/logger';
import db from './references.db.service';
import _ from 'lodash';

class ReferencesService {
  refLookUp(domain, refKey) {
    l.info(`${this.constructor.name}.refLookUp(${domain}, ${refKey})`);
    return new Promise((resolve, reject)=>{
      db.refLookUp(domain, refKey)
          .then((result)=> {
            l.info(`ReferencesService.refLookUp.then result: ${JSON.stringify(result, null, 2)} `);
              let transformedRest = {};
              transformedRest[domain] = {};
              _.forEach(_.orderBy(result, ['Code'], ['asc']), function(item){
                  transformedRest[domain][item.Code.trim()] = item.Value;
              });
              resolve(transformedRest);
           })
          .catch((error) => {
             reject(error);
          });
    });
  }
}

export default new ReferencesService();
